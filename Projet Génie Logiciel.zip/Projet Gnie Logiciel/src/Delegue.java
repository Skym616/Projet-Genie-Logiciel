import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3948e7a3-516a-47bc-ab17-c712b518f3da")
public class Delegue extends Personne {
    @objid ("589eff65-dbe2-4536-b9c4-5a83c0db26b7")
    public List<Rapport>  = new ArrayList<Rapport> ();

    @objid ("a2bc444b-cf29-46ed-8b15-7a95557c86bb")
    public List<Permission>  = new ArrayList<Permission> ();

    @objid ("cbaac091-0a57-4f71-9af7-c71a6adfd4d6")
    public List<Tache>  = new ArrayList<Tache> ();

    @objid ("908c4afd-e051-4be6-afbc-4d6d98bc40b8")
    public void valider_permission(int id) {
    }

    @objid ("e68de615-f1b2-4ed6-97d2-5260d5941dbd")
    public void refuser_permission(int id) {
    }

    @objid ("995856be-1751-4c44-aae7-bb968bb3a5db")
    public void ajouter_personne() {
    }

    @objid ("601b0e63-e328-4453-9c24-5bc23f73e3fc")
    public void attribuer_tache(Tache tache, int id) {
    }

    @objid ("67992265-5ce6-4de5-95f2-ad2b08e590c1")
    public void consulter_liste_presence() {
    }

    @objid ("c4a65df6-d996-44b0-986f-2ffe2fe3cdc8")
    public void consulter_liste_tache() {
    }

    @objid ("db9894cf-3220-4ef8-a6ea-6403c130629c")
    public void consulter_liste_rapport() {
    }

    @objid ("141ca9fc-13ac-4f6c-b888-a1eed5239287")
    public void consulter_rapport(int id) {
    }

}
