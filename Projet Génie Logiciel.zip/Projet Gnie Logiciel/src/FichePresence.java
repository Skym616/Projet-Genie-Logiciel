import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("7fc36c6a-ee5a-4756-a39c-3c41b5271b51")
public class FichePresence {
    @objid ("c80f3637-b14f-4c8e-a300-57ef8755be10")
    private String id;

    @objid ("78ce05b5-8331-4647-a3c7-bcec4d429f3e")
    private FicheItem[] fiche;

    @objid ("2beae1e6-a97e-4962-8517-8b3f47c05d27")
    private int creer_par;

    @objid ("d2386fc0-fc79-4278-afc6-9f2f3f7dd893")
    public void creer_fiche_presence() {
    }

}
