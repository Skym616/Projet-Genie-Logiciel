import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("227220fc-282c-402c-ae5d-d374b15709e5")
public class Presence {
    @objid ("365514f2-a727-4cce-b9a8-6403993079d0")
    private int id;

    @objid ("0be30713-bc54-498d-9564-379f6759bfb9")
    private Date date;

    @objid ("a6768057-14a1-4829-8210-a0781f7e92d3")
    private String heure;

    @objid ("9377aa25-8a54-4015-9e2d-ef359a2c02bb")
    private double longitude;

    @objid ("da499756-0199-43eb-a1a4-134362e087bc")
    private double latitude;

    @objid ("827cca0f-7357-45ae-bf5f-d5d19b6829e5")
    private int id_fiche;

    @objid ("97b56119-4ccf-49aa-971c-51d3a3d6081f")
    private int id_chserv;

    @objid ("06e7cc48-ee81-4bf2-9227-02f3fc81a61f")
    public void ajouter_presence() {
    }

    @objid ("4fb0b553-2fc2-4954-9a6b-38ff123b2c3b")
    public void supprimer_presence(int id) {
    }

}
