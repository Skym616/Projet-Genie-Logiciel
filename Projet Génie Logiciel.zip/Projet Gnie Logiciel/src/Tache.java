import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("34837099-edf7-4a33-8825-b47d0497da81")
public class Tache {
    @objid ("a34eaf6a-701c-46b1-b24b-e6bf953f0bb9")
    private int id;

    @objid ("c43f06ce-116a-41f9-921b-8b4353bd5954")
    private String titre;

    @objid ("e181fa4c-95a2-4188-9f02-32c75df46a19")
    private String description;

    @objid ("936a8364-ca53-40a6-8330-53ab643b37e1")
    private Date duree_tache;

    @objid ("fca87101-1dc8-4f90-83cd-5d3de5db758b")
    public int employe_concerne;

    @objid ("dd739c90-842a-4e48-82e9-35d60722c598")
    public void ajouter_tache() {
    }

    @objid ("c1f4e437-42cc-47e2-8ba2-10a8fb13a509")
    public void supprimer_tache(int id) {
    }

    @objid ("32e3f931-01cb-479c-8d4c-77828591972e")
    public void modifier_tache(int id) {
    }

}
