import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("e129f6e5-d58e-4048-9c0b-dc6231f5f5a1")
public class ChefService extends Personne {
    @objid ("7c32b047-5cd8-4d19-a863-9fe3ea83f938")
    public List<Rapport>  = new ArrayList<Rapport> ();

    @objid ("7d674a7b-7faa-4b0c-9ca3-fa4a6affe11d")
    public List<Permission>  = new ArrayList<Permission> ();

    @objid ("6ab8f977-b583-4779-a7c8-5023827ee7d6")
    public List<FichePresence>  = new ArrayList<FichePresence> ();

    @objid ("b250330b-a530-47ac-9045-ab24dc1ac427")
    public List<Tache>  = new ArrayList<Tache> ();

    @objid ("7232255c-3d8f-42d0-9ec8-c567723a34d6")
    public void consulter_tache(int id) {
    }

    @objid ("25fe3ee5-11f5-42ae-8802-bc29cde7ed0d")
    public void modifier_profil(int id) {
    }

    @objid ("faf5ddde-a233-46a9-b9fe-1340cc1b10e2")
    public void ajouter_rapport(Rapport rapport) {
    }

    @objid ("edac5885-9ef2-4667-ba44-42e60d2afb1f")
    public void consulter_liste_presence() {
    }

    @objid ("e56f9895-4294-490c-bed3-445e7d4a47d2")
    public void marquer_presence(int id) {
    }

}
