import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b764bd6f-878c-4b26-9524-23dbe238910b")
public class Personne {
    @objid ("f534d4ce-15f1-47d7-88db-7e74eab41082")
    protected String Matricule;

    @objid ("16e10983-8209-4893-b5f9-52f179eaa4eb")
    protected String Nom;

    @objid ("f823dbee-5e0d-4fa6-954d-1bfaa4d61279")
    protected String Email;

    @objid ("b228c405-9801-4d91-bb7d-192854da3c65")
    protected String Sexe;

    @objid ("93b6f9a1-0e0a-4b75-9f0f-6fc1a67124d2")
    protected Date Date_naissance;

    @objid ("4b0f77d3-66b7-41bc-8d25-557832f0fcfd")
    protected String Mot_de_passe;

    @objid ("5cfcc9bf-9086-4731-ba83-bc65c267671d")
    protected int Telephone;

    @objid ("06c6d356-235a-42cf-88f8-d164ebb9cf77")
    protected int id;

    @objid ("29ae10b3-c52e-446c-8c98-61097a8e3f32")
    protected void authentification(String email, String password) {
    }

    @objid ("a3feddbb-6b61-43d1-bef8-156df4fa21bb")
    protected void consulter_profil(int id) {
    }

}
