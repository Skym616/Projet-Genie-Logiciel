import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f6d585f6-7365-4496-8527-abbc8774fede")
public class Rapport {
    @objid ("b76dc7ca-c087-43f0-b723-14258f54e1e4")
    private String id;

    @objid ("f5432d0a-1f15-4fa8-bad8-c06cc8310f54")
    private String titre;

    @objid ("4ef7f95f-3ee9-4234-acfe-c071c2cde592")
    private String contenu;

    @objid ("8b95f38e-6cb6-4e1d-8550-6ac17d5037ab")
    private Date date_creation;

    @objid ("b7250ef2-8837-48d1-86ea-4eff9f1c986c")
    private String heure_creation;

    @objid ("79b8f1bf-de0d-4adc-a184-f3d6358a0ff5")
    public int cree_par;

    @objid ("014ee144-0c6e-462e-a1ff-ac341c09c533")
    public void ajouter_rapport() {
    }

    @objid ("6ca91a5c-b98d-4ecb-82d7-a55488c46690")
    public void modifier_rapport(int id) {
    }

    @objid ("82527e3b-16f7-4778-84c4-23e781e63a28")
    public void supprimer_rapport(int id) {
    }

}
