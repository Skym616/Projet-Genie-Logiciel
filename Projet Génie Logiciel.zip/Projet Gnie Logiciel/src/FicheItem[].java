import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.DataType;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@DataType
@objid ("6e206d5e-9992-4deb-a887-425a1a37d648")
public class FicheItem[] {
    @objid ("18cf61c4-2d72-46b1-9d18-d3136be8b7db")
    public Date date;

    @objid ("7d9b25ec-d085-4e4e-a9ad-1f71c646d5c4")
    public String nom;

    @objid ("3977d2a5-9cff-40c5-b8b6-1f56bf57a1b6")
    public boolean coche;

}
