import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("371390b4-9c9a-495b-86e7-1e5b8a4d205c")
public class Secretaire extends Personne {
    @objid ("cfcc5ab1-78bb-4b5a-ac00-656a14f73fbb")
    public List<Permission> permission = new ArrayList<Permission> ();

    @objid ("512c5906-da17-4294-b269-ce3285f35c22")
    public List<FichePresence>  = new ArrayList<FichePresence> ();

    @objid ("b4f60684-3236-48ec-8fc8-5b2e8bfb228d")
    public void consuler_liste_présence() {
    }

    @objid ("6431c4f8-e288-4c48-9ff8-cfa2b6f52690")
    public void Creer_fiche_presence() {
    }

}
