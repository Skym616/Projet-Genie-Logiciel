import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3a897dc9-dcce-4d09-a882-ec12493bd12e")
public class Permission {
    @objid ("33a86f40-e7b3-4282-9650-12b4017d511f")
    private int id;

    @objid ("645251be-6922-472e-8050-82b00cca25d5")
    private String motif;

    @objid ("1e5d2207-f024-484e-809d-97df885f754e")
    private Date date_debut;

    @objid ("d7853864-2da6-42f3-be43-0f68c832927f")
    private Date date_fin;

    @objid ("c1fb00bf-ff95-43f7-881d-623720352bfe")
    private String statut;

    @objid ("a950d12c-88fc-420c-af62-cc5fe57e2c6a")
    private int employé_concerne;

    @objid ("6f06a477-6a60-4f43-9c91-7e1a77f50ce0")
    public void ajouter_permission() {
    }

    @objid ("b99d3428-bd5a-4601-9ea3-425453ca4590")
    public void supprimer_permission() {
    }

    @objid ("0fe440aa-4d51-4288-9622-edbc8eb4865a")
    public void modifier_permission() {
    }

}
